﻿namespace SalondeBelleza
{
    partial class EditarClienteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNombre = new TextBox();
            txtTelefono = new TextBox();
            chkEsClienteFrecuente = new CheckBox();
            btnGuardar = new Button();
            SuspendLayout();
            // 
            // txtNombre
            // 
            txtNombre.BackColor = SystemColors.MenuHighlight;
            txtNombre.Location = new Point(158, 28);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(100, 23);
            txtNombre.TabIndex = 0;
            // 
            // txtTelefono
            // 
            txtTelefono.BackColor = SystemColors.MenuHighlight;
            txtTelefono.Location = new Point(158, 89);
            txtTelefono.Name = "txtTelefono";
            txtTelefono.Size = new Size(100, 23);
            txtTelefono.TabIndex = 1;
            // 
            // chkEsClienteFrecuente
            // 
            chkEsClienteFrecuente.AutoSize = true;
            chkEsClienteFrecuente.Location = new Point(166, 142);
            chkEsClienteFrecuente.Name = "chkEsClienteFrecuente";
            chkEsClienteFrecuente.Size = new Size(83, 19);
            chkEsClienteFrecuente.TabIndex = 2;
            chkEsClienteFrecuente.Text = "Recurrente";
            chkEsClienteFrecuente.UseVisualStyleBackColor = true;
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(174, 198);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 23);
            btnGuardar.TabIndex = 3;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // EditarClienteForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(401, 282);
            Controls.Add(btnGuardar);
            Controls.Add(chkEsClienteFrecuente);
            Controls.Add(txtTelefono);
            Controls.Add(txtNombre);
            Name = "EditarClienteForm";
            Text = "EditarClienteForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNombre;
        private TextBox txtTelefono;
        private CheckBox chkEsClienteFrecuente;
        private Button btnGuardar;
    }
}