﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalondeBelleza
{
    public partial class EditarClienteForm : Form
    {
        public Cliente ClienteEditado { get; private set; }

        public EditarClienteForm(Cliente cliente)
        {
            InitializeComponent();
            txtNombre.Text = cliente.Nombre;
            txtTelefono.Text = cliente.Telefono;
            chkEsClienteFrecuente.Checked = cliente.EsClienteFrecuente;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            // Validar la entrada de datos antes de guardar los cambios
            if (!string.IsNullOrEmpty(txtNombre.Text) && !string.IsNullOrEmpty(txtTelefono.Text))
            {
                ClienteEditado = new Cliente
                {
                    Nombre = txtNombre.Text,
                    Telefono = txtTelefono.Text,
                    EsClienteFrecuente = chkEsClienteFrecuente.Checked
                };
                DialogResult = DialogResult.OK; // Establecer el resultado del cuadro de diálogo como OK
                Close(); // Cerrar el formulario
            }
            else
            {
                MessageBox.Show("Por favor, complete todos los campos.");
            }
        }
    }
}