﻿namespace SalondeBelleza
{
    partial class AgregarCitaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtFecha = new TextBox();
            listaCitas = new ListBox();
            btnGuardar = new Button();
            SuspendLayout();
            // 
            // txtFecha
            // 
            txtFecha.Location = new Point(387, 148);
            txtFecha.Name = "txtFecha";
            txtFecha.Size = new Size(100, 23);
            txtFecha.TabIndex = 0;
            txtFecha.Click += btnGuardar_Click;
            // 
            // listaCitas
            // 
            listaCitas.FormattingEnabled = true;
            listaCitas.ItemHeight = 15;
            listaCitas.Location = new Point(362, 24);
            listaCitas.Name = "listaCitas";
            listaCitas.Size = new Size(120, 94);
            listaCitas.TabIndex = 1;
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(387, 189);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(75, 23);
            btnGuardar.TabIndex = 2;
            btnGuardar.Text = "button1";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // AgregarCitaForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnGuardar);
            Controls.Add(listaCitas);
            Controls.Add(txtFecha);
            Name = "AgregarCitaForm";
            Text = "AgregarCitaForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtFecha;
        private ListBox listaCitas;
        private Button btnGuardar;
    }
}