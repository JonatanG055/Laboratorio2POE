﻿namespace SalondeBelleza
{
    partial class GestionSalonBelleza
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBoxClientes = new ListBox();
            txtNombreCliente = new TextBox();
            txtTelefonoCliente = new TextBox();
            chkEsClienteFrecuente = new CheckBox();
            btnAgregarCliente = new Button();
            btnEditarCliente = new Button();
            btnEliminarCliente = new Button();
            listBoxCitas = new ListBox();
            btnAgregarCita = new Button();
            SuspendLayout();
            // 
            // listBoxClientes
            // 
            listBoxClientes.BackColor = SystemColors.Info;
            listBoxClientes.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            listBoxClientes.ForeColor = SystemColors.Highlight;
            listBoxClientes.FormattingEnabled = true;
            listBoxClientes.ItemHeight = 15;
            listBoxClientes.Location = new Point(14, 23);
            listBoxClientes.Name = "listBoxClientes";
            listBoxClientes.Size = new Size(316, 94);
            listBoxClientes.TabIndex = 0;
            // 
            // txtNombreCliente
            // 
            txtNombreCliente.BackColor = SystemColors.MenuHighlight;
            txtNombreCliente.Location = new Point(52, 135);
            txtNombreCliente.Name = "txtNombreCliente";
            txtNombreCliente.Size = new Size(219, 23);
            txtNombreCliente.TabIndex = 1;
            // 
            // txtTelefonoCliente
            // 
            txtTelefonoCliente.BackColor = SystemColors.HotTrack;
            txtTelefonoCliente.Location = new Point(124, 175);
            txtTelefonoCliente.Name = "txtTelefonoCliente";
            txtTelefonoCliente.Size = new Size(82, 23);
            txtTelefonoCliente.TabIndex = 2;
            // 
            // chkEsClienteFrecuente
            // 
            chkEsClienteFrecuente.AutoSize = true;
            chkEsClienteFrecuente.BackColor = SystemColors.AppWorkspace;
            chkEsClienteFrecuente.Location = new Point(124, 224);
            chkEsClienteFrecuente.Name = "chkEsClienteFrecuente";
            chkEsClienteFrecuente.Size = new Size(82, 19);
            chkEsClienteFrecuente.TabIndex = 3;
            chkEsClienteFrecuente.Text = "Recurrecte";
            chkEsClienteFrecuente.UseVisualStyleBackColor = false;
            // 
            // btnAgregarCliente
            // 
            btnAgregarCliente.BackColor = SystemColors.ControlLight;
            btnAgregarCliente.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnAgregarCliente.ForeColor = SystemColors.ActiveCaptionText;
            btnAgregarCliente.Location = new Point(52, 262);
            btnAgregarCliente.Name = "btnAgregarCliente";
            btnAgregarCliente.Size = new Size(75, 23);
            btnAgregarCliente.TabIndex = 4;
            btnAgregarCliente.Text = "Agregar";
            btnAgregarCliente.UseVisualStyleBackColor = false;
            btnAgregarCliente.Click += btnAgregarCliente_Click;
            // 
            // btnEditarCliente
            // 
            btnEditarCliente.BackColor = SystemColors.AppWorkspace;
            btnEditarCliente.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnEditarCliente.Location = new Point(131, 262);
            btnEditarCliente.Name = "btnEditarCliente";
            btnEditarCliente.Size = new Size(75, 23);
            btnEditarCliente.TabIndex = 5;
            btnEditarCliente.Text = "Editar";
            btnEditarCliente.UseVisualStyleBackColor = false;
            btnEditarCliente.Click += btnEditarCliente_Click;
            // 
            // btnEliminarCliente
            // 
            btnEliminarCliente.BackColor = SystemColors.ActiveCaptionText;
            btnEliminarCliente.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnEliminarCliente.ForeColor = SystemColors.ControlLightLight;
            btnEliminarCliente.Location = new Point(212, 262);
            btnEliminarCliente.Name = "btnEliminarCliente";
            btnEliminarCliente.Size = new Size(75, 23);
            btnEliminarCliente.TabIndex = 6;
            btnEliminarCliente.Text = "Eliminar";
            btnEliminarCliente.UseVisualStyleBackColor = false;
            btnEliminarCliente.Click += btnEliminarCliente_Click;
            // 
            // listBoxCitas
            // 
            listBoxCitas.BackColor = SystemColors.Info;
            listBoxCitas.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            listBoxCitas.ForeColor = SystemColors.Highlight;
            listBoxCitas.FormattingEnabled = true;
            listBoxCitas.ItemHeight = 15;
            listBoxCitas.Location = new Point(336, 23);
            listBoxCitas.Name = "listBoxCitas";
            listBoxCitas.Size = new Size(126, 139);
            listBoxCitas.TabIndex = 7;
            // 
            // btnAgregarCita
            // 
            btnAgregarCita.Location = new Point(344, 174);
            btnAgregarCita.Name = "btnAgregarCita";
            btnAgregarCita.Size = new Size(118, 23);
            btnAgregarCita.TabIndex = 8;
            btnAgregarCita.Text = "button1";
            btnAgregarCita.UseVisualStyleBackColor = true;
            btnAgregarCita.Click += btnAgregarCita_Click;
            // 
            // GestionSalonBelleza
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(642, 450);
            Controls.Add(btnAgregarCita);
            Controls.Add(listBoxCitas);
            Controls.Add(btnEliminarCliente);
            Controls.Add(btnEditarCliente);
            Controls.Add(btnAgregarCliente);
            Controls.Add(chkEsClienteFrecuente);
            Controls.Add(txtTelefonoCliente);
            Controls.Add(txtNombreCliente);
            Controls.Add(listBoxClientes);
            Name = "GestionSalonBelleza";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBoxClientes;
        private TextBox txtNombreCliente;
        private TextBox txtTelefonoCliente;
        private CheckBox chkEsClienteFrecuente;
        private Button btnAgregarCliente;
        private Button btnEditarCliente;
        private Button btnEliminarCliente;
        private ListBox listBoxCitas;
        private Button btnAgregarCita;
    }
}