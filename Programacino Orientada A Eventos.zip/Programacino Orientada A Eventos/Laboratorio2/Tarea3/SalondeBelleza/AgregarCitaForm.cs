﻿using System;
using System.Windows.Forms;

namespace SalondeBelleza
{
    public partial class AgregarCitaForm : Form
    {
        public Cita NuevaCita { get; private set; }
        private int clienteID;

        public AgregarCitaForm(int clienteID)
        {
            InitializeComponent();
            this.clienteID = clienteID;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DateTime.TryParse(txtFecha.Text, out DateTime fechaCita))
                {
                    int nuevaCitaID = listaCitas.Count + 1;
                    NuevaCita = new Cita
                    {
                        CitaID = nuevaCitaID,
                        ClienteID = clienteID,
                        FechaCita = fechaCita
                    };
                    listaCitas.Add(NuevaCita);
                    DialogResult = DialogResult.OK;
                    Close();
                }
                else
                {
                    MessageBox.Show("Por favor, ingrese una fecha y hora válidas.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
    }
}
