using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace SalondeBelleza
{
    public partial class GestionSalonBelleza : Form
    {
        private List<Cliente> listaClientes = new List<Cliente>();

        private List<Cita> listaCitas = new List<Cita>();

        private void MostrarCitas(int clienteID)
        {
            listBoxCitas.Items.Clear();
            foreach (var cita in listaCitas)
            {
                if (cita.ClienteID == clienteID)
                {
                    listBoxCitas.Items.Add(cita.FechaCita.ToString("dd/MM/yyyy HH:mm"));
                }
            }
        }
        private void listBoxClientes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBoxClientes.SelectedIndex >= 0)
            {
                int indiceSeleccionado = listBoxClientes.SelectedIndex;
                int clienteID = listaClientes[indiceSeleccionado].ClienteID;
                MostrarCitas(clienteID);
            }
        }

        private void btnAgregarCita_Click(object sender, EventArgs e)
        {
            if (listBoxClientes.SelectedIndex >= 0)
            {
                int indiceSeleccionado = listBoxClientes.SelectedIndex;
                int clienteID = listaClientes[indiceSeleccionado].ClienteID;

                // Abre un formulario para agregar citas
                AgregarCitaForm agregarCitaForm = new AgregarCitaForm(clienteID);
                if (agregarCitaForm.ShowDialog() == DialogResult.OK)
                {
                    // Agrega la cita a la lista de citas
                    listaCitas.Add(agregarCitaForm.NuevaCita);
                    MostrarCitas(clienteID);
                }
            }
            else
            {
                MessageBox.Show("Por favor, seleccione un cliente para agregar una cita.");
            }
        }


        public GestionSalonBelleza()
        {
            InitializeComponent();
        }


        private void MostrarClientes()
        {
            listBoxClientes.Items.Clear();
            foreach (var cliente in listaClientes)
            {
                listBoxClientes.Items.Add(cliente.Nombre);
            }
        }

        private void btnAgregarCliente_Click(object sender, EventArgs e)
        {
            // Validar la entrada de datos antes de agregar el cliente
            if (!string.IsNullOrEmpty(txtNombreCliente.Text) && !string.IsNullOrEmpty(txtTelefonoCliente.Text))
            {
                Cliente nuevoCliente = new Cliente
                {
                    ClienteID = listaClientes.Count + 1,
                    Nombre = txtNombreCliente.Text,
                    Telefono = txtTelefonoCliente.Text,
                    EsClienteFrecuente = chkEsClienteFrecuente.Checked
                };

                listaClientes.Add(nuevoCliente);
                MostrarClientes();
                LimpiarCamposCliente();
            }
            else
            {
                MessageBox.Show("Por favor, complete todos los campos.");
            }
        }

        private void btnEditarCliente_Click(object sender, EventArgs e)
        {
            // Verificar si se ha seleccionado un cliente en el ListBox
            if (listBoxClientes.SelectedIndex >= 0)
            {
                int indiceSeleccionado = listBoxClientes.SelectedIndex;
                Cliente clienteSeleccionado = listaClientes[indiceSeleccionado];

                // Crear una instancia del formulario EditarClienteForm
                EditarClienteForm editarClienteForm = new EditarClienteForm(clienteSeleccionado);

                // Mostrar el formulario para editar el cliente
                if (editarClienteForm.ShowDialog() == DialogResult.OK)
                {
                    // Actualizar el cliente con los cambios realizados en el cuadro de di�logo
                    listaClientes[indiceSeleccionado] = editarClienteForm.ClienteEditado;
                    MostrarClientes();
                }
            }
            else
            {
                MessageBox.Show("Por favor, seleccione un cliente para editar.");
            }
        }


        private void btnEliminarCliente_Click(object sender, EventArgs e)
        {
            // Verificar si se ha seleccionado un cliente en el ListBox
            if (listBoxClientes.SelectedIndex >= 0)
            {
                int indiceSeleccionado = listBoxClientes.SelectedIndex;
                listaClientes.RemoveAt(indiceSeleccionado);
                MostrarClientes();
            }
            else
            {
                MessageBox.Show("Por favor, seleccione un cliente para eliminar.");
            }
        }

        private void LimpiarCamposCliente()
        {
            txtNombreCliente.Clear();
            txtTelefonoCliente.Clear();
            chkEsClienteFrecuente.Checked = false;
        }
    }
}
