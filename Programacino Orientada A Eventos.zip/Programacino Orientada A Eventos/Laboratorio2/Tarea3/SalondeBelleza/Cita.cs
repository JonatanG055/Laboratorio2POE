﻿namespace SalondeBelleza
{
    public class Cita
    {
        public int CitaID { get; set; }
        public int ClienteID { get; set; }
        public DateTime FechaCita { get; set; }
    }
}
